# Elliptical ViewData

# Installation

##npm

``` bash

git clone https://github.com/ellipticaljs/viewdata.git
npm install

```

##bower

``` bash

bower install elliptical-viewdata

```

# Usage

``` html

<link rel="import" href="bower_components/elliptical-viewdata/elliptical-viewdata.html">

```
ELLIPTICAL TEMPLATE EXTENSIONS
===========================
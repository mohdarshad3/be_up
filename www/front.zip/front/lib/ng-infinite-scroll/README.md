ng-infinite-scroll
==================

Angular.js directive that implements infinite scroll functionality

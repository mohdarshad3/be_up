es5 Class Abstraction
===========================

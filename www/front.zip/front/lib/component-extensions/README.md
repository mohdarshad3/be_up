Prototype extensions/behaviors for web components
===========================


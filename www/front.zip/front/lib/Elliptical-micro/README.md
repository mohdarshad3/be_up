Elliptical-micro
===========================

Minimal function custom element sugar
coffee -c *.coffee
compass compile
mkdir dist
mv slider.css slider.js dist

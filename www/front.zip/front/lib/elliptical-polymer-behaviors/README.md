Elliptical behaviors for Polymer components
===========================

# Notice
Due to object.observe being removed from ES6, the observable-behavior behavior is now deprecated and will be removed in the next minor release.

# Installation

##bower

``` bash

bower install elliptical-polymer-behaviors

```

##demo

http://ellipticaljs.github.io/polymer-behaviors/
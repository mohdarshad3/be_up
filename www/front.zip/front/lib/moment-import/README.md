# MOMENT-IMPORT

Reference the moment library using html imports.



## Installation

``` bash

bower install moment-import --save

```

## Usage

```html
<link rel="import" href="bower_components/moment-import/moment.html">


```

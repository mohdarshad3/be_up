# GSAP-IMPORT

Reference the gsap animation library using html imports.



## Installation

``` bash

bower install gsap-import --save

```

## Usage

```html
<!--TweenMax-->
<link rel="import" href="bower_components/gsap-import/gsap.html">

<!--minified version-->
<link rel="import" href="bower_components/gsap-import/gsap-min.html">




```

# ASYNC-IMPORT

Reference the async library using html imports.



## Installation

``` bash

bower install async-import --save

```

## Usage

```html
<link rel="import" href="bower_components/async-import/async.html">


```

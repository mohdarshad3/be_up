An es6 Map dependency injection container
=========================================


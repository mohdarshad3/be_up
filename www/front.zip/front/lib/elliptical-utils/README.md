# Elliptical Utils

es6 javascript utilities lib


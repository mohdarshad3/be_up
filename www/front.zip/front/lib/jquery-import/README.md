# JQUERY-IMPORT

Reference the jquery library using html imports.



## Installation

``` bash

bower install jquery-import --save

```

## Usage

```html
<link rel="import" href="bower_components/jquery-import/jquery.html">


```
